# clear workspace
rm(list=ls())

# install packages

# install.packages("ggplot2")
# install.packages("dplyr")
# install.packages("readr")

# load packages
library(ggplot2)
library(dplyr)
library(readr)

########### Exercise 1: Write and read read in your data
# set working directory (place where you want to store your file)
# setwd("C:\...")
# write data into this working directory
write_csv(diamonds, "my_di.csv")
# read the date from the working directory
my_di <- read_csv("my_di.csv")

# speed comparison between read_csv to base function read.csv
system.time(read_csv("my_di.csv"))
system.time(read.csv("my_di.csv"))

my_di


########### Exercise 2: Selecting and renaming variables
# a)
my_di <- my_di %>% select(-clarity)

# b)
my_di %>% select(starts_with("c"))

# c) # rename works as select, but keeps all columns
my_di <- my_di %>% rename(length.mm=x, width.mm=y, depth.mm=z)


########### Exercise 3: Selecting and renaming variables
# a)
my_di <- my_di %>% mutate_if(is.character,as.factor)

# b)
my_di <- my_di %>% mutate(price = as.double(price))

# c)
# one solution
my_di <- my_di %>% 
  mutate(length.mm = ifelse(length.mm == 0, NA, length.mm),
         width.mm = ifelse(width.mm == 0, NA, width.mm),
         depth.mm = ifelse(depth.mm == 0, NA, depth.mm))
# alternative
my_di <- my_di %>% 
  mutate(length.mm = na_if(length.mm, 0),
         width.mm = na_if(width.mm, 0),
         depth.mm = na_if(depth.mm, 0))

# other alternative
my_di <- my_di %>% mutate_at(vars(ends_with(".mm")), funs(na_if(., 0)))

# d)
my_di <- my_di %>% mutate(price_euro=price*1.1282)

# e)	
my_di <- my_di %>% mutate(carat_timesten=10*carat,depth_timesten=10*depth)
# alternative
my_di <- my_di %>% mutate_at(vars(carat,depth), funs(timesten=.*10))

# f)
mutate_at(my_di, vars(carat,depth), funs(.*10))

# g)
my_di <- my_di %>% select(-contains("_"))

# h) 
my_di <- my_di %>% group_by(color) %>% mutate(mean_price = mean(price),
                                              median_price = median(price))
my_di <- my_di %>% select(-contains("_"))
my_di <- my_di %>% ungroup


######################## exercise 4: Descriptive statistics

# a)
col_NAs <- my_di %>% summarize_all(function (x) sum(is.na(x)))
# alternative:
col_NAs <- my_di %>% summarize_all(funs(sum(is.na(.))))

# a slower alternative with the R base function apply
# col_NAs <- apply(my_di,2,function (x) sum(is.na(x)))

# b)
# slow solution with dplyr package (dplyr not really efficient for rowwise operations)
# my_di %>%
#  rowwise %>%
#  summarise(NA_per_row = sum(is.na(.)))

# for comparison: a faster alternative with the R base function apply
 row_NAs <- apply(my_di,1,function (x) sum(is.na(x)))
# similar alternative
 row_NAs <- sapply(my_di,function (x) sum(is.na(x)))
 
# or faster solution using the tidyverse package 
# library(tidyverse)
# map(my_di, ~sum(is.na(.)))

# c)
group_stats <- my_di %>% group_by(cut,color) %>% summarize(mean_price=mean(price),
                                                                     sd_price=sd(price))
# or
group_stats <- my_di %>% group_by_at(vars(cut,color)) %>% summarize(mean_price=mean(price),
                                                     sd_price=sd(price))
group_stats %>% arrange(mean_price)

# d)
my_di %>% summarize_if(is.numeric,min,na.rm=TRUE)
my_di %>% summarize_if(is.numeric,median,na.rm=TRUE)

# more compact alternative
my_di %>% summarize_if(is.numeric,funs(min(.,na.rm=TRUE), median(.,na.rm=TRUE)))

# e) 
# just two examples for the sake of motivation
ggplot(group_stats, aes(mean_price,sd_price)) +
  geom_point(aes()) +
  geom_smooth() +
  scale_size_area()

my_di %>% select(depth,table) %>% boxplot
